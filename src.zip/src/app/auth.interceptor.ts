import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from './auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const token = auth.token();
  const isAuthPublic =
    req.url.includes('/auth/login-student') ||
    req.url.includes('/auth/login-admin') ||
    req.url.includes('/auth/register-student');
  if (token && !isAuthPublic) {
    req = req.clone({ setHeaders: { Authorization: `Bearer ${token}` } });
  }
  return next(req);
};
